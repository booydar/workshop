#! /usr/bin/env python3
# coding: utf-8
import unittest
from pyalpha.petri_net import PetriNet

class TestPetriNet(unittest.TestCase):
    pass